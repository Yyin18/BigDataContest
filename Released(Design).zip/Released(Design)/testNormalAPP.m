classdef testNormalAPP < matlab.uitest.TestCase
    properties
        App
    end
    
    methods (TestMethodSetup)
        function launchApp(testCase)
            
            testCase.App = app;
            x1 = huangzhong;
            
            testCase.App.huangz = x1;
            x2 = zhaoyun;

            testCase.App.zhaoy = x2;
            x3 = machao;

            testCase.App.mac = x3;
            x4 = zhangfei;

            testCase.App.zhangf = x4;
            x5 = caocao;

            testCase.App.caoc = x5;
            x6 = guanyu;

            testCase.App.guany = x6;
            x7 = zu1;

            testCase.App.z1 = x7;
            x8 = zu2;

            testCase.App.z2 = x8;
            x9 = zu3;

            testCase.App.z3 = x9;
            x10 = zu4;

            testCase.App.z4 = x10;
            
            %testCase.addTeardown(@delete,testCase.App);
        end
    end
    methods (Test)
        function test_SelectButtonPushed(testCase)
            % State: No order for the table and no dish selected
            % Input: Choose appetizer 1 and press select button
            % Expected Output: OrderList has appetizer 1's name, amount and
            % unit price
            testCase.press(testCase.App.InitKlotskiButton);
            pause(5)
            %testCase.click(testCase.App.zu1);
           % pause(1)
%             testCase.verifyEqual(testCase.App.OrderList.Data{1},testCase.App.appetizer1Node.Text);
%              testCase.verifyEqual(testCase.App.OrderList.Data{2},1);
%               testCase.verifyEqual(testCase.App.OrderList.Data{3},testCase.App.appetizer1Node.NodeData);
        end
        
    end
    
end