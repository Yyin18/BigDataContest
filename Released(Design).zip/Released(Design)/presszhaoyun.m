function presszhaoyun(tc)
    tc.press(tc.App.UIFigure, tc.App.zhaoyun.Position(1:2)+[10, 10]);
    pause(1);
end