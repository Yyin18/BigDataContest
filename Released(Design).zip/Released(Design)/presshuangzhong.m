function presshuangzhong(tc)
    tc.press(tc.App.UIFigure, tc.App.huangzhong.Position(1:2)+[10, 10]);
    pause(1);
end