function presscaocao(tc)
    tc.press(tc.App.UIFigure, tc.App.caocao.Position(1:2)+[10, 10]);
    pause(1);
end