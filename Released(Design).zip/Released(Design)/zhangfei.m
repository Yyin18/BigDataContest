classdef zhangfei < handle
    properties(Access = public)
        length = 2;
        width = 1;
        position = [0, 0];
        id = 4;
    end
end