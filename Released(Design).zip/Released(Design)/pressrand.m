function pressrand(tc)
    a = randi(5);
    b = randi(4);
    
    tc.press(tc.App.UIFigure, [b*100+50,a*100+50]);
    pause(0.001);
end