function rr = BFS(state)
    queue = [state];
    newqueue=[];    
    for t = 1:100000
        for i = 1:4:size(queue,2)            
            curstate=queue(:,i:(i+3));
            if curstate(4,2)==5 && curstate(5,3)==5
                rr=1;
                return;
            end
            res=allstate(curstate);
            newqueue=[newqueue,res];
        end
        queue=newqueue;
        newqueue=[];        
        length =size(queue,2);
        if length>50000*4
            rr=-1;            
            return
        end 
    end    
end
