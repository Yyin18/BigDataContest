function result = allstate(curr)
    
    state1 = [];
    result = [];
    for i = 1:5
        for j = 1:4
            if curr(i, j) == -1
                state1 = [state1; i, j];
            end
        end
    end
    move = [1,1,1,1;1,1,1,1];
    if state1(1, 2) == 1
        move(1,3) = 0;
    end
    if state1(1, 1) == 1
        move(1,1) = 0;
    end
    if state1(1, 2) == 4
        move(1,4) = 0;
    end
    if state1(1, 1) == 5
        move(1,2) = 0;
    end
    
    if state1(2, 2) == 1
        move(2,3) = 0;
    end
    if state1(2, 1) == 1
        move(2,1) = 0;
    end
    if state1(2, 2) == 4
        move(2,4) = 0;
    end
    if state1(2, 1) == 5
        move(2,2) = 0;
    end
    if abs(state1(1, 1) - state1(2, 1)) == 1 && state1(1, 2) == state1(2, 2) %vertical 2
        if move(1, 1) == 1
            if curr(state1(1, 1)-1, state1(1, 2)) == 1 || curr(state1(1, 1)-1, state1(1, 2)) == 2 || curr(state1(1, 1)-1, state1(1, 2)) == 3 || curr(state1(1, 1)-1, state1(1, 2)) == 4
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                cur1(state1(1, 1)-2, state1(1, 2)) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1)-1, state1(1, 2)) == 10 || curr(state1(1, 1)-1, state1(1, 2)) == 9 || curr(state1(1, 1)-1, state1(1, 2)) == 8 || curr(state1(1, 1)-1, state1(1, 2)) == 7
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                cur1(state1(1, 1)-1, state1(1, 2)) = -1;
                result = [result cur1];
            end
            
        end
        if move(2, 2) == 1
            if curr(state1(2, 1)+1, state1(2, 2)) == 1 || curr(state1(2, 1)+1, state1(2, 2)) == 2 || curr(state1(2, 1)+1, state1(2, 2)) == 3 || curr(state1(2, 1)+1, state1(2, 2)) == 4
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)+1, state1(2, 2));
                cur1(state1(2, 1)+2, state1(2, 2)) = -1;
                result = [result cur1];
            elseif curr(state1(2, 1)+1, state1(2, 2)) == 10 || curr(state1(2, 1)+1, state1(2, 2)) == 9 || curr(state1(2, 1)+1, state1(2, 2)) == 8 || curr(state1(2, 1)+1, state1(2, 2)) == 7
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)+1, state1(2, 2));
                cur1(state1(2, 1)+1, state1(2, 2)) = -1;
                result = [result cur1];
            end
        end
        if move(1, 3) == 1
            if curr(state1(1, 1), state1(1, 2)-1) == curr(state1(2, 1), state1(2, 2)-1) && (curr(state1(1, 1), state1(1, 2)-1) == 1 || curr(state1(1, 1), state1(1, 2)-1) == 2 || curr(state1(1, 1), state1(1, 2)-1) == 3 || curr(state1(1, 1), state1(1, 2)-1) == 4)
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                cur1(state1(1, 1), state1(1, 2)-1) = -1;
                cur1(state1(2, 1), state1(2, 2)-1) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1), state1(1, 2)-1) == curr(state1(2, 1), state1(2, 2)-1) && curr(state1(1, 1), state1(1, 2)-1) == 5
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                cur1(state1(1, 1), state1(1, 2)-2) = -1;
                cur1(state1(2, 1), state1(2, 2)-2) = -1;
                result = [result cur1];
            else
                if curr(state1(1, 1), state1(1, 2)-1) == 7 || curr(state1(1, 1), state1(1, 2)-1) == 8 || curr(state1(1, 1), state1(1, 2)-1) == 9 || curr(state1(1, 1), state1(1, 2)-1) == 10
                    cur1 = curr;
                    cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                    cur1(state1(1, 1), state1(1, 2)-1) = -1;
                    result = [result cur1];
                elseif curr(state1(1, 1), state1(1, 2)-1) == 6
                    cur1 = curr;
                    cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                    cur1(state1(1, 1), state1(1, 2)-2) = -1;
                    result = [result cur1];
                end
                
                if curr(state1(2, 1), state1(2, 2)-1) == 7 || curr(state1(2, 1), state1(2, 2)-1) == 8 || curr(state1(2, 1), state1(2, 2)-1) == 9 || curr(state1(2, 1), state1(2, 2)-1) == 10
                    cur1 = curr;
                    cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)-1);
                    cur1(state1(2, 1), state1(2, 2)-1) = -1;
                    result = [result cur1];
                elseif curr(state1(2, 1), state1(2, 2)-1) == 6
                    cur1 = curr;
                    cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)-1);
                    cur1(state1(2, 1), state1(2, 2)-2) = -1;
                    result = [result cur1];
                end
            end
        end
        if move(1, 4) == 1
            if curr(state1(1, 1), state1(1, 2)+1) == curr(state1(2, 1), state1(2, 2)+1) && (curr(state1(1, 1), state1(1, 2)+1) == 1 || curr(state1(1, 1), state1(1, 2)+1) == 2 || curr(state1(1, 1), state1(1, 2)+1) == 3 || curr(state1(1, 1), state1(1, 2)+1) == 4)
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)+1);
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(1, 1), state1(1, 2)+1);
                cur1(state1(1, 1), state1(1, 2)+1) = -1;
                cur1(state1(2, 1), state1(2, 2)+1) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1), state1(1, 2)+1) == curr(state1(2, 1), state1(2, 2)+1) && curr(state1(1, 1), state1(1, 2)+1) == 5
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)+1);
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(1, 1), state1(1, 2)+1);
                cur1(state1(1, 1), state1(1, 2)+2) = -1;
                cur1(state1(2, 1), state1(2, 2)+2) = -1;
                result = [result cur1];
            else
                if curr(state1(1, 1), state1(1, 2)+1) == 7 || curr(state1(1, 1), state1(1, 2)+1) == 8 || curr(state1(1, 1), state1(1, 2)+1) == 9 || curr(state1(1, 1), state1(1, 2)+1) == 10
                    cur1 = curr;
                    cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)+1);
                    cur1(state1(1, 1), state1(1, 2)+1) = -1;
                    result = [result cur1];
                elseif curr(state1(1, 1), state1(1, 2)+1) == 6
                    cur1 = curr;
                    cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)+1);
                    cur1(state1(1, 1), state1(1, 2)+2) = -1;
                    result = [result cur1];
                end
                
                if curr(state1(2, 1), state1(2, 2)+1) == 7 || curr(state1(2, 1), state1(2, 2)+1) == 8 || curr(state1(2, 1), state1(2, 2)+1) == 9 || curr(state1(2, 1), state1(2, 2)+1) == 10
                    cur1 = curr;
                    cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)+1);
                    cur1(state1(2, 1), state1(2, 2)+1) = -1;
                    result = [result cur1];
                elseif curr(state1(2, 1), state1(2, 2)+1) == 6
                    cur1 = curr;
                    cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)+1);
                    cur1(state1(2, 1), state1(2, 2)+2) = -1;
                    result = [result cur1];
                end
            end
        end
    elseif  abs(state1(1, 2) - state1(2, 2)) == 1 && state1(1, 1) == state1(2, 1) %horizonal 2
        if move(1, 1) == 1
            if curr(state1(1, 1)-1, state1(1, 2)) == curr(state1(2, 1)-1, state1(2, 2)) && curr(state1(1, 1)-1, state1(1, 2)) == 6
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                cur1(state1(1, 1)-1, state1(1, 2)) = -1;
                cur1(state1(2, 1)-1, state1(2, 2)) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1)-1, state1(1, 2)) == curr(state1(2, 1)-1, state1(2, 2)) && curr(state1(1, 1)-1, state1(1, 2)) == 5
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                cur1(state1(1, 1)-2, state1(1, 2)) = -1;
                cur1(state1(2, 1)-2, state1(2, 2)) = -1;
                result = [result cur1];
            else
                if curr(state1(1, 1)-1, state1(1, 2)) == 7 || curr(state1(1, 1)-1, state1(1, 2)) == 8 || curr(state1(1, 1)-1, state1(1, 2)) == 9 || curr(state1(1, 1)-1, state1(1, 2)) == 10
                    cur1 = curr;
                    cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                    cur1(state1(1, 1)-1, state1(1, 2)) = -1;
                    result = [result cur1];
                elseif curr(state1(1, 1)-1, state1(1, 2)) == 1 || curr(state1(1, 1)-1, state1(1, 2)) == 2 || curr(state1(1, 1)-1, state1(1, 2)) == 3 || curr(state1(1, 1)-1, state1(1, 2)) == 4
                    cur1 = curr;
                    cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                    cur1(state1(1, 1)-2, state1(1, 2)) = -1;
                    result = [result cur1];
                end
                
                if curr(state1(2, 1)-1, state1(2, 2)) == 7 || curr(state1(2, 1)-1, state1(2, 2)) == 8 || curr(state1(2, 1)-1, state1(2, 2)) == 9 || curr(state1(2, 1)-1, state1(2, 2)) == 10
                    cur1 = curr;
                    cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)-1, state1(2, 2));
                    cur1(state1(2, 1)-1, state1(2, 2)) = -1;
                    result = [result cur1];
                elseif curr(state1(2, 1)-1, state1(2, 2)) == 1 || curr(state1(2, 1)-1, state1(2, 2)) == 2 || curr(state1(2, 1)-1, state1(2, 2)) == 3 || curr(state1(2, 1)-1, state1(2, 2)) == 4
                    cur1 = curr;
                    cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)-1, state1(2, 2));
                    cur1(state1(2, 1)-2, state1(2, 2)) = -1;
                    result = [result cur1];
                end
            end
            
            
        end
        if move(1, 2) == 1
            if curr(state1(1, 1)+1, state1(1, 2)) == curr(state1(2, 1)+1, state1(2, 2)) && curr(state1(1, 1)+1, state1(1, 2)) == 6
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)+1, state1(1, 2));
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)+1, state1(2, 2));
                cur1(state1(1, 1)+1, state1(1, 2)) = -1;
                cur1(state1(2, 1)+1, state1(2, 2)) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1)+1, state1(1, 2)) == curr(state1(2, 1)+1, state1(2, 2)) && curr(state1(1, 1)+1, state1(1, 2)) == 5
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)+1, state1(1, 2));
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)+1, state1(2, 2));
                cur1(state1(1, 1)+2, state1(1, 2)) = -1;
                cur1(state1(2, 1)+2, state1(2, 2)) = -1;
                result = [result cur1];
            else
                if curr(state1(1, 1)+1, state1(1, 2)) == 7 || curr(state1(1, 1)+1, state1(1, 2)) == 8 || curr(state1(1, 1)+1, state1(1, 2)) == 9 || curr(state1(1, 1)+1, state1(1, 2)) == 10
                    cur1 = curr;
                    cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)+1, state1(1, 2));
                    cur1(state1(1, 1)+1, state1(1, 2)) = -1;
                    result = [result cur1];
                elseif curr(state1(1, 1)+1, state1(1, 2)) == 1 || curr(state1(1, 1)+1, state1(1, 2)) == 2 || curr(state1(1, 1)+1, state1(1, 2)) == 3 || curr(state1(1, 1)+1, state1(1, 2)) == 4
                    cur1 = curr;
                    cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)+1, state1(1, 2));
                    cur1(state1(1, 1)+2, state1(1, 2)) = -1;
                    result = [result cur1];
                end
                
                if curr(state1(2, 1)+1, state1(2, 2)) == 7 || curr(state1(2, 1)+1, state1(2, 2)) == 8 || curr(state1(2, 1)+1, state1(2, 2)) == 9 || curr(state1(2, 1)+1, state1(2, 2)) == 10
                    cur1 = curr;
                    cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)+1, state1(2, 2));
                    cur1(state1(2, 1)+1, state1(2, 2)) = -1;
                    result = [result cur1];
                elseif curr(state1(2, 1)+1, state1(2, 2)) == 1 || curr(state1(2, 1)+1, state1(2, 2)) == 2 || curr(state1(2, 1)+1, state1(2, 2)) == 3 || curr(state1(2, 1)+1, state1(2, 2)) == 4
                    cur1 = curr;
                    cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)+1, state1(2, 2));
                    cur1(state1(2, 1)+2, state1(2, 2)) = -1;
                    result = [result cur1];
                end
            end
        end
        if move(1, 3) == 1
            if curr(state1(1, 1), state1(1, 2)-1) == 6
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                cur1(state1(1, 1), state1(1, 2)-2) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1), state1(1, 2)-1) == 10 || curr(state1(1, 1), state1(1, 2)-1) == 9 || curr(state1(1, 1), state1(1, 2)-1) == 8 || curr(state1(1, 1), state1(1, 2)-1) == 7
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                cur1(state1(1, 1), state1(1, 2)-1) = -1;
                result = [result cur1];
            end
        end
        if move(2, 4) == 1
            if curr(state1(2, 1), state1(2, 2)+1) == 6
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)+1);
                cur1(state1(2, 1), state1(2, 2)+2) = -1;
                result = [result cur1];
            elseif curr(state1(2, 1), state1(2, 2)+1) == 10 || curr(state1(2, 1), state1(2, 2)+1) == 9 || curr(state1(2, 1), state1(2, 2)+1) == 8 || curr(state1(2, 1), state1(2, 2)+1) == 7
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)+1);
                cur1(state1(2, 1), state1(2, 2)+1) = -1;
                result = [result cur1];
            end
        end
    else
        if move(1, 1) == 1
            if curr(state1(1, 1)-1, state1(1, 2)) == 1 || curr(state1(1, 1)-1, state1(1, 2)) == 2 || curr(state1(1, 1)-1, state1(1, 2)) == 3 || curr(state1(1, 1)-1, state1(1, 2)) == 4
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                cur1(state1(1, 1)-2, state1(1, 2)) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1)-1, state1(1, 2)) == 10 || curr(state1(1, 1)-1, state1(1, 2)) == 9 || curr(state1(1, 1)-1, state1(1, 2)) == 8 || curr(state1(1, 1)-1, state1(1, 2)) == 7
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)-1, state1(1, 2));
                cur1(state1(1, 1)-1, state1(1, 2)) = -1;
                result = [result cur1];
            end
        end
        if move(1, 2) == 1
            if curr(state1(1, 1)+1, state1(1, 2)) == 1 || curr(state1(1, 1)+1, state1(1, 2)) == 2 || curr(state1(1, 1)+1, state1(1, 2)) == 3 || curr(state1(1, 1)+1, state1(1, 2)) == 4
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)+1, state1(1, 2));
                cur1(state1(1, 1)+2, state1(1, 2)) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1)+1, state1(1, 2)) == 10 || curr(state1(1, 1)+1, state1(1, 2)) == 9 || curr(state1(1, 1)+1, state1(1, 2)) == 8 || curr(state1(1, 1)+1, state1(1, 2)) == 7
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1)+1, state1(1, 2));
                cur1(state1(1, 1)+1, state1(1, 2)) = -1;
                result = [result cur1];
            end
        end
        if move(1, 3) == 1
            if curr(state1(1, 1), state1(1, 2)-1) == 6
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                cur1(state1(1, 1), state1(1, 2)-2) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1), state1(1, 2)-1) == 10 || curr(state1(1, 1), state1(1, 2)-1) == 9 || curr(state1(1, 1), state1(1, 2)-1) == 8 || curr(state1(1, 1), state1(1, 2)-1) == 7
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)-1);
                cur1(state1(1, 1), state1(1, 2)-1) = -1;
                result = [result cur1];
            end
        end
        if move(1, 4) == 1
            if curr(state1(1, 1), state1(1, 2)+1) == 6
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)+1);
                cur1(state1(1, 1), state1(1, 2)+2) = -1;
                result = [result cur1];
            elseif curr(state1(1, 1), state1(1, 2)+1) == 10 || curr(state1(1, 1), state1(1, 2)+1) == 9 || curr(state1(1, 1), state1(1, 2)+1) == 8 || curr(state1(1, 1), state1(1, 2)+1) == 7
                cur1 = curr;
                cur1(state1(1, 1), state1(1, 2)) = curr(state1(1, 1), state1(1, 2)+1);
                cur1(state1(1, 1), state1(1, 2)+1) = -1;
                result = [result cur1];
            end
        end
        
        if move(2, 1) == 1
            if curr(state1(2, 1)-1, state1(2, 2)) == 1 || curr(state1(2, 1)-1, state1(2, 2)) == 2 || curr(state1(2, 1)-1, state1(2, 2)) == 3 || curr(state1(2, 1)-1, state1(2, 2)) == 4
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)-1, state1(2, 2));
                cur1(state1(2, 1)-2, state1(2, 2)) = -1;
                result = [result cur1];
            elseif curr(state1(2, 1)-1, state1(2, 2)) == 10 || curr(state1(2, 1)-1, state1(2, 2)) == 9 || curr(state1(2, 1)-1, state1(2, 2)) == 8 || curr(state1(2, 1)-1, state1(2, 2)) == 7
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)-1, state1(2, 2));
                cur1(state1(2, 1)-1, state1(2, 2)) = -1;
                result = [result cur1];
            end
        end
        if move(2, 2) == 1
            if curr(state1(2, 1)+1, state1(2, 2)) == 1 || curr(state1(2, 1)+1, state1(2, 2)) == 2 || curr(state1(2, 1)+1, state1(2, 2)) == 3 || curr(state1(2, 1)+1, state1(2, 2)) == 4
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)+1, state1(2, 2));
                cur1(state1(2, 1)+2, state1(2, 2)) = -1;
                result = [result cur1];
            elseif curr(state1(2, 1)+1, state1(2, 2)) == 10 || curr(state1(2, 1)+1, state1(2, 2)) == 9 || curr(state1(2, 1)+1, state1(2, 2)) == 8 || curr(state1(2, 1)+1, state1(2, 2)) == 7
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1)+1, state1(2, 2));
                cur1(state1(2, 1)+1, state1(2, 2)) = -1;
                result = [result cur1];
            end
        end
        if move(2, 3) == 1
            if curr(state1(2, 1), state1(2, 2)-1) == 6
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)-1);
                cur1(state1(2, 1), state1(2, 2)-2) = -1;
                result = [result cur1];
            elseif curr(state1(2, 1), state1(2, 2)-1) == 10 || curr(state1(2, 1), state1(2, 2)-1) == 9 || curr(state1(2, 1), state1(2, 2)-1) == 8 || curr(state1(2, 1), state1(2, 2)-1) == 7
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)-1);
                cur1(state1(2, 1), state1(2, 2)-1) = -1;
                result = [result cur1];
            end
        end
        if move(2, 4) == 1
            if curr(state1(2, 1), state1(2, 2)+1) == 6
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)+1);
                cur1(state1(2, 1), state1(2, 2)+2) = -1;
                result = [result cur1];
            elseif curr(state1(2, 1), state1(2, 2)+1) == 10 || curr(state1(2, 1), state1(2, 2)+1) == 9 || curr(state1(2, 1), state1(2, 2)+1) == 8 || curr(state1(2, 1), state1(2, 2)+1) == 7
                cur1 = curr;
                cur1(state1(2, 1), state1(2, 2)) = curr(state1(2, 1), state1(2, 2)+1);
                cur1(state1(2, 1), state1(2, 2)+1) = -1;
                result = [result cur1];
            end
        end
        
    end
    %result = move;
end