close all
clear all
x1 = huangzhong;
xapp = Interface;
xapp.huangz = x1;
x2 = zhaoyun;

xapp.zhaoy = x2;
x3 = machao;

xapp.mac = x3;
x4 = zhangfei;

xapp.zhangf = x4;
x5 = caocao;

xapp.caoc = x5;
x6 = guanyu;

xapp.guany = x6;
x7 = zu1;

xapp.z1 = x7;
x8 = zu2;

xapp.z2 = x8;
x9 = zu3;

xapp.z3 = x9;
x10 = zu4;

xapp.z4 = x10;

