function presszu3(tc)
    tc.press(tc.App.UIFigure, tc.App.zu3.Position(1:2)+[10, 10]);
    pause(1);
end