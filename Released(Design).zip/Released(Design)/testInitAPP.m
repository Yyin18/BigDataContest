classdef testInitAPP < matlab.uitest.TestCase
    properties
        App
    end
    
    methods (TestMethodSetup)
        function launchApp(testCase)
            testCase.App = app;
            x1 = huangzhong;
            testCase.App.huangz = x1;
            x2 = zhaoyun;
            testCase.App.zhaoy = x2;
            x3 = machao;
            testCase.App.mac = x3;
            x4 = zhangfei;
            testCase.App.zhangf = x4;
            x5 = caocao;
            testCase.App.caoc = x5;
            x6 = guanyu;
            testCase.App.guany = x6;
            x7 = zu1;
            testCase.App.z1 = x7;
            x8 = zu2;
            testCase.App.z2 = x8;
            x9 = zu3;
            testCase.App.z3 = x9;
            x10 = zu4;
            testCase.App.z4 = x10;
            
            %testCase.addTeardown(@delete,testCase.App);
        end
    end
    methods (Test)
        function test_select(testCase)
            pause(1);
            testCase.press(testCase.App.InitKlotskiButton);
            pause(10);
            pressdrop(testCase);
            presspre1(testCase);
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1);
            pressdrop(testCase);
            presspre2(testCase);
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1);
            pressdrop(testCase);
            presspre3(testCase);
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1);
            pressdrop(testCase);
            presspre4(testCase);
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1);
        
%             % State: No order for the table and no dish selected
%             % Input: Choose appetizer 1 and press select button
%             % Expected Output: OrderList has appetizer 1's name, amount and
%             % unit price
            testCase.press(testCase.App.QuitButton);
            pause(3)
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1)
            
            pressdrop(testCase);
            presspre5(testCase);
            testCase.press(testCase.App.InitKlotskiButton);
            pause(3); 
            testCase.press(testCase.App.TestButton);
            pause(2); 
            pressdrop(testCase);
            presspre1(testCase);
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1);  
            
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1)
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1)
            
            presszu2(testCase);
            presszu1(testCase);
            presszu1(testCase);
            testCase.press(testCase.App.ResetButton);
            pause(1);
            testCase.press(testCase.App.ResetButton);
            pause(1);
            testCase.press(testCase.App.ResetButton);
            pause(2);
            pressguanyu(testCase);
            pressmachao(testCase);
            pressmachao(testCase);
            pause(3);
            presszu3(testCase);
            pause(3);
            presszu3(testCase);
            pressmachao(testCase);
            testCase.press(testCase.App.Button_15);
            pause(1);
            pressmachao(testCase);
            pressmachao(testCase);
            testCase.press(testCase.App.Button_3);
            pause(1);
            presshuangzhong(testCase);
            presszhangfei(testCase);
            presszhangfei(testCase);
            pause(2);
            presszu4(testCase);
            presszu4(testCase);
            presszhangfei(testCase);
            testCase.press(testCase.App.Button_4);
            pause(1);
            presshuangzhong(testCase);
            presszu3(testCase);
            presszu3(testCase);
            testCase.press(testCase.App.Button_11);
            pause(1);
            presscaocao(testCase);
            pause(3)
            testCase.press(testCase.App.QuitButton);
            pause(1);
            
            
            
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1);
            pressdrop(testCase);
            pressdropr(testCase);
            testCase.press(testCase.App.InitKlotskiButton);
            pause(1);
            
            
            for i = 1:3
                testCase.press(testCase.App.InitKlotskiButton);
                pause(1);
            end
            pause(1);
            for i = 1:80
                pressrand(testCase);
            end
            for i = 1:30
                testCase.press(testCase.App.ResetButton);
            end
            testCase.press(testCase.App.QuitButton);
            pause(3)
        end
    end
    
end