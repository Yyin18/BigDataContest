function presszhangfei(tc)
    tc.press(tc.App.UIFigure, tc.App.zhangfei.Position(1:2)+[10, 10]);
    pause(1);
end