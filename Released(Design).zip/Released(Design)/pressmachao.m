function pressmachao(tc)
    tc.press(tc.App.UIFigure, tc.App.machao.Position(1:2)+[10, 10]);
    pause(1);
end