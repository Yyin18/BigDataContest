function presspre1(tc)

    
    tc.press(tc.App.UIFigure, tc.App.DropDown.Position(1:2)+[50,20-60]);
    pause(1);
end