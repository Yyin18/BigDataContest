function presszu4(tc)
    tc.press(tc.App.UIFigure, tc.App.zu4.Position(1:2)+[10, 10]);
    pause(1);
end