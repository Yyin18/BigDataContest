classdef zu2 < handle
    properties(Access = public)
        length = 1;
        width = 1;
        position = [0, 0];
        id = 8;
    end
end