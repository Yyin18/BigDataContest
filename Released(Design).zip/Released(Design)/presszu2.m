function presszu2(tc)
    tc.press(tc.App.UIFigure, tc.App.zu2.Position(1:2)+[10, 10]);
    pause(1);
end