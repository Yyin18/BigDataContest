classdef zhaoyun < handle
    properties(Access = public)
        length = 2;
        width = 1;
        position = [0, 0];
        id = 2;
    end
end