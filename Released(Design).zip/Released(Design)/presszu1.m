function presszu1(tc)
    tc.press(tc.App.UIFigure, tc.App.zu1.Position(1:2)+[10, 10]);
    pause(1);
end