classdef guanyu < handle
    properties(Access = public)
        length = 1;
        width = 2;
        position = [0, 0];
        id = 6;
    end
end