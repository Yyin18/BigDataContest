classdef setclass < handle
    properties (Access = public)
        app
        huangz
        zhaoy
        mac
        zhangf
        caoc
        guany
        z1
        z2
        z3
        z4
    end
    methods
        function class = setclass(self, app, id)
            
        end
    end
end
