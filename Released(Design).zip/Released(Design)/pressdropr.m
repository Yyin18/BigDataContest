function pressdropr(tc)

    
    tc.press(tc.App.UIFigure, tc.App.DropDown.Position(1:2)+[50,20-30]);
    pause(1);
end