classdef caocao < handle
    properties(Access = public)
        length = 2;
        width = 2;
        position = [0, 0];
        id = 5;
    end
end